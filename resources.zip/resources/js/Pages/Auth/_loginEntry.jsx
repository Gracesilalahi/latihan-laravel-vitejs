// resources/js/Pages/Auth/_loginEntry.jsx
import Login from './Login.jsx';
export default Login;
